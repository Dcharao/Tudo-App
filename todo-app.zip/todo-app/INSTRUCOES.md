# 📝 Lista de Tarefas - Instruções de Instalação e Execução

## Trabalho Final - Linguagem de Programação para Internet
**Desenvolvido por:** [Seu Nome]  
**Data:** 25/06/2025

---

## 📋 Sobre o Projeto

Este é um sistema completo de gerenciamento de lista de tarefas desenvolvido com:
- **Frontend:** React.js com React Router DOM
- **Backend:** Node.js + Express.js
- **Banco de Dados:** MongoDB
- **Estilização:** CSS puro responsivo

### ✅ Funcionalidades Implementadas

- **CRUD Completo:** Criar, visualizar, editar e excluir tarefas
- **Navegação:** 4 páginas (Lista, Cadastro, Edição, Detalhes)
- **Filtros:** Por status (pendentes/concluídas) e categoria
- **Categorias:** Trabalho, Pessoal, Estudos, Saúde, Outros
- **Prioridades:** Alta, Média, Baixa
- **Imagens:** Suporte a URLs de imagens
- **Datas:** Data de criação e vencimento
- **Interface Responsiva:** Funciona em desktop e mobile
- **Estatísticas:** Contadores de tarefas em tempo real

---

## 🚀 Como Executar o Projeto

### Pré-requisitos
- Node.js (versão 14 ou superior)
- MongoDB (local ou MongoDB Atlas)
- Git

### 1. Backend (API)

```bash
# Navegar para a pasta do backend
cd backend

# Instalar dependências
npm install

# Configurar variáveis de ambiente (opcional)
# Criar arquivo .env com:
# PORT=5000
# MONGODB_URI=mongodb://localhost:27017/todoapp

# Iniciar MongoDB (se usando local)
sudo systemctl start mongod

# Executar o servidor
npm start
```

O backend estará disponível em: `http://localhost:5000`

### 2. Frontend (React)

```bash
# Abrir novo terminal e navegar para a pasta do frontend
cd frontend

# Instalar dependências
npm install

# Executar a aplicação
npm start
```

O frontend estará disponível em: `http://localhost:3000`

---

## 🌐 URLs da Aplicação

- **Página Inicial:** http://localhost:3000/
- **Nova Tarefa:** http://localhost:3000/cadastrar
- **Editar Tarefa:** http://localhost:3000/editar/:id
- **Detalhes:** http://localhost:3000/detalhes/:id

---

## 📡 API Endpoints

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/tarefas` | Lista todas as tarefas |
| GET | `/api/tarefas/:id` | Busca tarefa por ID |
| POST | `/api/tarefas` | Cria nova tarefa |
| PUT | `/api/tarefas/:id` | Atualiza tarefa |
| DELETE | `/api/tarefas/:id` | Exclui tarefa |

### Exemplo de JSON para criar tarefa:
```json
{
  "titulo": "Estudar React",
  "descricao": "Revisar conceitos de hooks",
  "categoria": "Estudos",
  "prioridade": "Alta",
  "imagem": "https://exemplo.com/imagem.jpg",
  "dataVencimento": "2025-07-01"
}
```

---

## 📁 Estrutura do Projeto

```
todo-app/
├── backend/                 # API Node.js/Express
│   ├── controllers/         # Lógica de negócio
│   ├── models/             # Modelos do MongoDB
│   ├── routes/             # Rotas da API
│   ├── server.js           # Servidor principal
│   └── package.json        # Dependências do backend
├── frontend/               # Aplicação React
│   ├── src/
│   │   ├── components/     # Componentes reutilizáveis
│   │   ├── pages/          # Páginas da aplicação
│   │   ├── services/       # Configuração da API
│   │   └── App.js          # Componente principal
│   └── package.json        # Dependências do frontend
└── README.md              # Documentação
```

---

## 🎯 Conceitos React Aplicados

- ✅ **useState:** Gerenciamento de estado local
- ✅ **useEffect:** Efeitos colaterais e ciclo de vida
- ✅ **Props:** Passagem de dados entre componentes
- ✅ **Props Desestruturados:** Extração de propriedades
- ✅ **Lift State Up:** Estado compartilhado
- ✅ **Renderização Condicional:** Exibição baseada em condições
- ✅ **Eventos:** onClick, onChange, onSubmit
- ✅ **React Router:** Navegação entre páginas
- ✅ **Axios:** Requisições HTTP

---

## 🛠️ Tecnologias Utilizadas

### Frontend
- React 18
- React Router DOM
- Axios
- CSS3 (responsivo)

### Backend
- Node.js
- Express.js
- MongoDB
- Mongoose
- CORS
- dotenv

---

## 🐛 Solução de Problemas

### Backend não conecta ao MongoDB
```bash
# Verificar se o MongoDB está rodando
sudo systemctl status mongod

# Iniciar o MongoDB se necessário
sudo systemctl start mongod
```

### Erro de CORS
- O backend já está configurado com CORS habilitado
- Verifique se as URLs estão corretas no frontend

### Porta já em uso
- Backend: Altere a porta no arquivo `.env` ou `server.js`
- Frontend: O React automaticamente sugerirá uma porta alternativa

---

## 📝 Notas Importantes

1. **Banco de Dados:** As tarefas são persistidas no MongoDB
2. **Imagens:** Use URLs válidas para as imagens das tarefas
3. **Responsividade:** A interface se adapta a diferentes tamanhos de tela
4. **Validação:** Campos obrigatórios são validados no frontend

---

## 🎓 Critérios de Avaliação Atendidos

- ✅ **CRUD completo** (3 pts)
- ✅ **Navegação com React Router** (2 pts) 
- ✅ **Interações e exibição** (1 pt)
- ✅ **Separação em componentes** (2 pts)
- ✅ **Código claro e organizado** (2 pts)
- ✅ **useState, useEffect, props, eventos, axios** (2.5 pts)
- ✅ **Renderização condicional** (1.5 pts)
- ✅ **Rotas REST e Express** (2 pts)
- ✅ **MongoDB com Mongoose** (2 pts)
- ✅ **Layout responsivo** (2 pts)
- ✅ **Estilos consistentes** (1 pt)
- ✅ **Imagens e textos organizados** (4 pts)
- ✅ **README completo** (4 pts)

**Total:** 30 pontos + possível bônus por hospedagem

---

## 📞 Suporte

Em caso de dúvidas na execução:
1. Verifique se todas as dependências foram instaladas
2. Confirme se o MongoDB está rodando
3. Verifique se as portas 3000 e 5000 estão livres
4. Consulte os logs de erro no terminal

