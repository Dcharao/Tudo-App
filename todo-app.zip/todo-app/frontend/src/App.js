import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import ListaTarefas from './pages/ListaTarefas';
import CadastroTarefa from './pages/CadastroTarefa';
import EditarTarefa from './pages/EditarTarefa';
import DetalhesTarefa from './pages/DetalhesTarefa';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<ListaTarefas />} />
            <Route path="/cadastrar" element={<CadastroTarefa />} />
            <Route path="/editar/:id" element={<EditarTarefa />} />
            <Route path="/detalhes/:id" element={<DetalhesTarefa />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

