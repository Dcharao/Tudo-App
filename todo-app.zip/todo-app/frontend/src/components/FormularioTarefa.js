import React, { useState, useEffect } from 'react';
import './FormularioTarefa.css';

const FormularioTarefa = ({ tarefa, onSubmit, onCancel, isEditing = false }) => {
  const [formData, setFormData] = useState({
    titulo: '',
    descricao: '',
    categoria: 'Outros',
    prioridade: 'Média',
    imagem: '',
    dataVencimento: ''
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (tarefa && isEditing) {
      setFormData({
        titulo: tarefa.titulo || '',
        descricao: tarefa.descricao || '',
        categoria: tarefa.categoria || 'Outros',
        prioridade: tarefa.prioridade || 'Média',
        imagem: tarefa.imagem || '',
        dataVencimento: tarefa.dataVencimento ? 
          new Date(tarefa.dataVencimento).toISOString().split('T')[0] : ''
      });
    }
  }, [tarefa, isEditing]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Limpar erro do campo quando o usuário começar a digitar
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.titulo.trim()) {
      newErrors.titulo = 'Título é obrigatório';
    }
    
    if (!formData.descricao.trim()) {
      newErrors.descricao = 'Descrição é obrigatória';
    }
    
    if (formData.imagem && !isValidUrl(formData.imagem)) {
      newErrors.imagem = 'URL da imagem inválida';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      const dataToSubmit = {
        ...formData,
        dataVencimento: formData.dataVencimento || null
      };
      onSubmit(dataToSubmit);
    }
  };

  return (
    <div className="formulario-container">
      <form onSubmit={handleSubmit} className="formulario-tarefa">
        <div className="form-group">
          <label htmlFor="titulo">Título *</label>
          <input
            type="text"
            id="titulo"
            name="titulo"
            value={formData.titulo}
            onChange={handleChange}
            className={errors.titulo ? 'error' : ''}
            placeholder="Digite o título da tarefa"
          />
          {errors.titulo && <span className="error-message">{errors.titulo}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="descricao">Descrição *</label>
          <textarea
            id="descricao"
            name="descricao"
            value={formData.descricao}
            onChange={handleChange}
            className={errors.descricao ? 'error' : ''}
            placeholder="Descreva a tarefa"
            rows="4"
          />
          {errors.descricao && <span className="error-message">{errors.descricao}</span>}
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="categoria">Categoria</label>
            <select
              id="categoria"
              name="categoria"
              value={formData.categoria}
              onChange={handleChange}
            >
              <option value="Trabalho">💼 Trabalho</option>
              <option value="Pessoal">👤 Pessoal</option>
              <option value="Estudos">📚 Estudos</option>
              <option value="Saúde">🏥 Saúde</option>
              <option value="Outros">📋 Outros</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="prioridade">Prioridade</label>
            <select
              id="prioridade"
              name="prioridade"
              value={formData.prioridade}
              onChange={handleChange}
            >
              <option value="Baixa">🟢 Baixa</option>
              <option value="Média">🟡 Média</option>
              <option value="Alta">🔴 Alta</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="imagem">URL da Imagem</label>
          <input
            type="url"
            id="imagem"
            name="imagem"
            value={formData.imagem}
            onChange={handleChange}
            className={errors.imagem ? 'error' : ''}
            placeholder="https://exemplo.com/imagem.jpg"
          />
          {errors.imagem && <span className="error-message">{errors.imagem}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="dataVencimento">Data de Vencimento</label>
          <input
            type="date"
            id="dataVencimento"
            name="dataVencimento"
            value={formData.dataVencimento}
            onChange={handleChange}
            min={new Date().toISOString().split('T')[0]}
          />
        </div>

        <div className="form-actions">
          <button type="button" onClick={onCancel} className="btn btn-cancelar">
            Cancelar
          </button>
          <button type="submit" className="btn btn-salvar">
            {isEditing ? 'Atualizar' : 'Criar'} Tarefa
          </button>
        </div>
      </form>
    </div>
  );
};

export default FormularioTarefa;

