import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Header.css';

const Header = () => {
  const location = useLocation();

  return (
    <header className="header">
      <div className="header-container">
        <Link to="/" className="logo">
          <h1>📝 Lista de Tarefas</h1>
        </Link>
        <nav className="nav">
          <Link 
            to="/" 
            className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
          >
            Início
          </Link>
          <Link 
            to="/cadastrar" 
            className={`nav-link ${location.pathname === '/cadastrar' ? 'active' : ''}`}
          >
            Nova Tarefa
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;

