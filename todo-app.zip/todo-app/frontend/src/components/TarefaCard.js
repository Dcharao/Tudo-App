import React from 'react';
import { Link } from 'react-router-dom';
import './TarefaCard.css';

const TarefaCard = ({ tarefa, onExcluir, onToggleConcluida }) => {
  const { _id, titulo, descricao, categoria, prioridade, concluida, imagem, dataVencimento } = tarefa;

  const formatarData = (data) => {
    if (!data) return '';
    return new Date(data).toLocaleDateString('pt-BR');
  };

  const getPrioridadeClass = (prioridade) => {
    switch (prioridade) {
      case 'Alta': return 'prioridade-alta';
      case 'Média': return 'prioridade-media';
      case 'Baixa': return 'prioridade-baixa';
      default: return 'prioridade-media';
    }
  };

  const getCategoriaIcon = (categoria) => {
    switch (categoria) {
      case 'Trabalho': return '💼';
      case 'Pessoal': return '👤';
      case 'Estudos': return '📚';
      case 'Saúde': return '🏥';
      default: return '📋';
    }
  };

  return (
    <div className={`tarefa-card ${concluida ? 'concluida' : ''}`}>
      <div className="tarefa-header">
        <div className="tarefa-categoria">
          <span className="categoria-icon">{getCategoriaIcon(categoria)}</span>
          <span className="categoria-text">{categoria}</span>
        </div>
        <div className={`prioridade-badge ${getPrioridadeClass(prioridade)}`}>
          {prioridade}
        </div>
      </div>

      {imagem && (
        <div className="tarefa-imagem">
          <img src={imagem} alt={titulo} />
        </div>
      )}

      <div className="tarefa-content">
        <h3 className="tarefa-titulo">{titulo}</h3>
        <p className="tarefa-descricao">{descricao}</p>
        
        {dataVencimento && (
          <div className="tarefa-vencimento">
            <span>📅 Vencimento: {formatarData(dataVencimento)}</span>
          </div>
        )}
      </div>

      <div className="tarefa-actions">
        <button
          className={`btn-toggle ${concluida ? 'btn-desfazer' : 'btn-concluir'}`}
          onClick={() => onToggleConcluida(_id, !concluida)}
        >
          {concluida ? '↩️ Desfazer' : '✅ Concluir'}
        </button>
        
        <Link to={`/detalhes/${_id}`} className="btn btn-detalhes">
          👁️ Ver
        </Link>
        
        <Link to={`/editar/${_id}`} className="btn btn-editar">
          ✏️ Editar
        </Link>
        
        <button
          className="btn btn-excluir"
          onClick={() => onExcluir(_id)}
        >
          🗑️ Excluir
        </button>
      </div>
    </div>
  );
};

export default TarefaCard;

