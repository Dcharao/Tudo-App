import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const tarefasAPI = {
  // Listar todas as tarefas
  listarTarefas: () => api.get('/tarefas'),
  
  // Buscar tarefa por ID
  buscarTarefaPorId: (id) => api.get(`/tarefas/${id}`),
  
  // Criar nova tarefa
  criarTarefa: (tarefa) => api.post('/tarefas', tarefa),
  
  // Atualizar tarefa
  atualizarTarefa: (id, tarefa) => api.put(`/tarefas/${id}`, tarefa),
  
  // Excluir tarefa
  excluirTarefa: (id) => api.delete(`/tarefas/${id}`),
};

export default api;

