import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import TarefaCard from '../components/TarefaCard';
import { tarefasAPI } from '../services/api';
import './ListaTarefas.css';

const ListaTarefas = () => {
  const [tarefas, setTarefas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filtro, setFiltro] = useState('todas');
  const [categoriaFiltro, setCategoriaFiltro] = useState('todas');

  useEffect(() => {
    carregarTarefas();
  }, []);

  const carregarTarefas = async () => {
    try {
      setLoading(true);
      const response = await tarefasAPI.listarTarefas();
      setTarefas(response.data);
      setError('');
    } catch (err) {
      setError('Erro ao carregar tarefas. Verifique se o servidor está rodando.');
      console.error('Erro ao carregar tarefas:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluirTarefa = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta tarefa?')) {
      try {
        await tarefasAPI.excluirTarefa(id);
        setTarefas(tarefas.filter(tarefa => tarefa._id !== id));
      } catch (err) {
        setError('Erro ao excluir tarefa');
        console.error('Erro ao excluir tarefa:', err);
      }
    }
  };

  const handleToggleConcluida = async (id, concluida) => {
    try {
      const tarefa = tarefas.find(t => t._id === id);
      const tarefaAtualizada = { ...tarefa, concluida };
      
      await tarefasAPI.atualizarTarefa(id, tarefaAtualizada);
      
      setTarefas(tarefas.map(t => 
        t._id === id ? { ...t, concluida } : t
      ));
    } catch (err) {
      setError('Erro ao atualizar tarefa');
      console.error('Erro ao atualizar tarefa:', err);
    }
  };

  const tarefasFiltradas = tarefas.filter(tarefa => {
    const filtroStatus = filtro === 'todas' || 
                        (filtro === 'pendentes' && !tarefa.concluida) ||
                        (filtro === 'concluidas' && tarefa.concluida);
    
    const filtroCategoria = categoriaFiltro === 'todas' || 
                           tarefa.categoria === categoriaFiltro;
    
    return filtroStatus && filtroCategoria;
  });

  const estatisticas = {
    total: tarefas.length,
    pendentes: tarefas.filter(t => !t.concluida).length,
    concluidas: tarefas.filter(t => t.concluida).length
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Carregando tarefas...</p>
      </div>
    );
  }

  return (
    <div className="lista-tarefas-container">
      <div className="lista-header">
        <div className="titulo-section">
          <h2>Minhas Tarefas</h2>
          <Link to="/cadastrar" className="btn btn-novo">
            ➕ Nova Tarefa
          </Link>
        </div>

        <div className="estatisticas">
          <div className="stat-card">
            <span className="stat-number">{estatisticas.total}</span>
            <span className="stat-label">Total</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">{estatisticas.pendentes}</span>
            <span className="stat-label">Pendentes</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">{estatisticas.concluidas}</span>
            <span className="stat-label">Concluídas</span>
          </div>
        </div>

        <div className="filtros">
          <div className="filtro-group">
            <label>Status:</label>
            <select 
              value={filtro} 
              onChange={(e) => setFiltro(e.target.value)}
              className="filtro-select"
            >
              <option value="todas">Todas</option>
              <option value="pendentes">Pendentes</option>
              <option value="concluidas">Concluídas</option>
            </select>
          </div>

          <div className="filtro-group">
            <label>Categoria:</label>
            <select 
              value={categoriaFiltro} 
              onChange={(e) => setCategoriaFiltro(e.target.value)}
              className="filtro-select"
            >
              <option value="todas">Todas</option>
              <option value="Trabalho">💼 Trabalho</option>
              <option value="Pessoal">👤 Pessoal</option>
              <option value="Estudos">📚 Estudos</option>
              <option value="Saúde">🏥 Saúde</option>
              <option value="Outros">📋 Outros</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="error-message">
          <p>{error}</p>
          <button onClick={carregarTarefas} className="btn btn-retry">
            Tentar Novamente
          </button>
        </div>
      )}

      <div className="tarefas-grid">
        {tarefasFiltradas.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📝</div>
            <h3>Nenhuma tarefa encontrada</h3>
            <p>
              {tarefas.length === 0 
                ? 'Comece criando sua primeira tarefa!'
                : 'Tente ajustar os filtros ou criar uma nova tarefa.'
              }
            </p>
            <Link to="/cadastrar" className="btn btn-primary">
              ➕ Criar Primeira Tarefa
            </Link>
          </div>
        ) : (
          tarefasFiltradas.map(tarefa => (
            <TarefaCard
              key={tarefa._id}
              tarefa={tarefa}
              onExcluir={handleExcluirTarefa}
              onToggleConcluida={handleToggleConcluida}
            />
          ))
        )}
      </div>
    </div>
  );
};

export default ListaTarefas;

