import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { tarefasAPI } from '../services/api';
import './DetalhesTarefa.css';

const DetalhesTarefa = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tarefa, setTarefa] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    carregarTarefa();
  }, [id]);

  const carregarTarefa = async () => {
    try {
      setLoading(true);
      const response = await tarefasAPI.buscarTarefaPorId(id);
      setTarefa(response.data);
      setError('');
    } catch (err) {
      setError('Erro ao carregar tarefa');
      console.error('Erro ao carregar tarefa:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = async () => {
    if (window.confirm('Tem certeza que deseja excluir esta tarefa?')) {
      try {
        await tarefasAPI.excluirTarefa(id);
        navigate('/', { 
          state: { 
            message: 'Tarefa excluída com sucesso!',
            type: 'success'
          }
        });
      } catch (error) {
        console.error('Erro ao excluir tarefa:', error);
        alert('Erro ao excluir tarefa. Tente novamente.');
      }
    }
  };

  const handleToggleConcluida = async () => {
    try {
      const tarefaAtualizada = { ...tarefa, concluida: !tarefa.concluida };
      await tarefasAPI.atualizarTarefa(id, tarefaAtualizada);
      setTarefa(tarefaAtualizada);
    } catch (error) {
      console.error('Erro ao atualizar tarefa:', error);
      alert('Erro ao atualizar tarefa. Tente novamente.');
    }
  };

  const formatarData = (data) => {
    if (!data) return 'Não definida';
    return new Date(data).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatarDataSimples = (data) => {
    if (!data) return 'Não definida';
    return new Date(data).toLocaleDateString('pt-BR');
  };

  const getPrioridadeClass = (prioridade) => {
    switch (prioridade) {
      case 'Alta': return 'prioridade-alta';
      case 'Média': return 'prioridade-media';
      case 'Baixa': return 'prioridade-baixa';
      default: return 'prioridade-media';
    }
  };

  const getCategoriaIcon = (categoria) => {
    switch (categoria) {
      case 'Trabalho': return '💼';
      case 'Pessoal': return '👤';
      case 'Estudos': return '📚';
      case 'Saúde': return '🏥';
      default: return '📋';
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Carregando tarefa...</p>
      </div>
    );
  }

  if (error || !tarefa) {
    return (
      <div className="error-container">
        <div className="error-message">
          <h3>Erro ao carregar tarefa</h3>
          <p>{error || 'Tarefa não encontrada'}</p>
          <button onClick={carregarTarefa} className="btn btn-retry">
            Tentar Novamente
          </button>
          <Link to="/" className="btn btn-voltar">
            Voltar
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="detalhes-tarefa-container">
      <div className="detalhes-header">
        <Link to="/" className="btn-voltar-link">
          ← Voltar para Lista
        </Link>
        
        <div className="status-badge">
          {tarefa.concluida ? (
            <span className="status concluida">✅ Concluída</span>
          ) : (
            <span className="status pendente">⏳ Pendente</span>
          )}
        </div>
      </div>

      <div className="detalhes-card">
        <div className="card-header">
          <div className="categoria-info">
            <span className="categoria-icon">{getCategoriaIcon(tarefa.categoria)}</span>
            <span className="categoria-text">{tarefa.categoria}</span>
          </div>
          <div className={`prioridade-badge ${getPrioridadeClass(tarefa.prioridade)}`}>
            {tarefa.prioridade}
          </div>
        </div>

        <h1 className="tarefa-titulo">{tarefa.titulo}</h1>

        {tarefa.imagem && (
          <div className="tarefa-imagem">
            <img src={tarefa.imagem} alt={tarefa.titulo} />
          </div>
        )}

        <div className="tarefa-descricao">
          <h3>Descrição</h3>
          <p>{tarefa.descricao}</p>
        </div>

        <div className="tarefa-info">
          <div className="info-grid">
            <div className="info-item">
              <span className="info-label">📅 Data de Criação:</span>
              <span className="info-value">{formatarData(tarefa.dataCriacao)}</span>
            </div>
            
            <div className="info-item">
              <span className="info-label">⏰ Data de Vencimento:</span>
              <span className="info-value">{formatarDataSimples(tarefa.dataVencimento)}</span>
            </div>
            
            <div className="info-item">
              <span className="info-label">📊 Status:</span>
              <span className="info-value">
                {tarefa.concluida ? 'Concluída' : 'Pendente'}
              </span>
            </div>
            
            <div className="info-item">
              <span className="info-label">🏷️ Categoria:</span>
              <span className="info-value">{tarefa.categoria}</span>
            </div>
            
            <div className="info-item">
              <span className="info-label">⚡ Prioridade:</span>
              <span className="info-value">{tarefa.prioridade}</span>
            </div>
          </div>
        </div>

        <div className="actions-section">
          <button
            className={`btn btn-toggle ${tarefa.concluida ? 'btn-desfazer' : 'btn-concluir'}`}
            onClick={handleToggleConcluida}
          >
            {tarefa.concluida ? '↩️ Marcar como Pendente' : '✅ Marcar como Concluída'}
          </button>
          
          <Link to={`/editar/${tarefa._id}`} className="btn btn-editar">
            ✏️ Editar
          </Link>
          
          <button className="btn btn-excluir" onClick={handleExcluir}>
            🗑️ Excluir
          </button>
        </div>
      </div>
    </div>
  );
};

export default DetalhesTarefa;

