import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import FormularioTarefa from '../components/FormularioTarefa';
import { tarefasAPI } from '../services/api';
import './EditarTarefa.css';

const EditarTarefa = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tarefa, setTarefa] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    carregarTarefa();
  }, [id]);

  const carregarTarefa = async () => {
    try {
      setLoading(true);
      const response = await tarefasAPI.buscarTarefaPorId(id);
      setTarefa(response.data);
      setError('');
    } catch (err) {
      setError('Erro ao carregar tarefa');
      console.error('Erro ao carregar tarefa:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (dadosTarefa) => {
    try {
      await tarefasAPI.atualizarTarefa(id, dadosTarefa);
      navigate('/', { 
        state: { 
          message: 'Tarefa atualizada com sucesso!',
          type: 'success'
        }
      });
    } catch (error) {
      console.error('Erro ao atualizar tarefa:', error);
      alert('Erro ao atualizar tarefa. Tente novamente.');
    }
  };

  const handleCancel = () => {
    navigate('/');
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Carregando tarefa...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <div className="error-message">
          <h3>Erro ao carregar tarefa</h3>
          <p>{error}</p>
          <button onClick={carregarTarefa} className="btn btn-retry">
            Tentar Novamente
          </button>
          <button onClick={handleCancel} className="btn btn-voltar">
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="editar-tarefa-container">
      <div className="page-header">
        <h2>✏️ Editar Tarefa</h2>
        <p>Atualize os dados da tarefa abaixo</p>
      </div>
      
      <FormularioTarefa
        tarefa={tarefa}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        isEditing={true}
      />
    </div>
  );
};

export default EditarTarefa;

