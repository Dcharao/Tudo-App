import React from 'react';
import { useNavigate } from 'react-router-dom';
import FormularioTarefa from '../components/FormularioTarefa';
import { tarefasAPI } from '../services/api';
import './CadastroTarefa.css';

const CadastroTarefa = () => {
  const navigate = useNavigate();

  const handleSubmit = async (dadosTarefa) => {
    try {
      await tarefasAPI.criarTarefa(dadosTarefa);
      navigate('/', { 
        state: { 
          message: 'Tarefa criada com sucesso!',
          type: 'success'
        }
      });
    } catch (error) {
      console.error('Erro ao criar tarefa:', error);
      alert('Erro ao criar tarefa. Tente novamente.');
    }
  };

  const handleCancel = () => {
    navigate('/');
  };

  return (
    <div className="cadastro-tarefa-container">
      <div className="page-header">
        <h2>📝 Nova Tarefa</h2>
        <p>Preencha os dados abaixo para criar uma nova tarefa</p>
      </div>
      
      <FormularioTarefa
        onSubmit={handleSubmit}
        onCancel={handleCancel}
        isEditing={false}
      />
    </div>
  );
};

export default CadastroTarefa;

