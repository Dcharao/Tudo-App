# Frontend - Lista de Tarefas

Aplicação web frontend desenvolvida com React para gerenciamento de lista de tarefas.

## Tecnologias Utilizadas

- React 18
- React Router DOM
- Axios
- CSS3 (CSS puro)
- JavaScript ES6+

## Funcionalidades

- ✅ **CRUD Completo**: Criar, visualizar, editar e excluir tarefas
- 🔍 **Filtros**: Filtrar tarefas por status (todas, pendentes, concluídas) e categoria
- 📊 **Estatísticas**: Visualizar contadores de tarefas total, pendentes e concluídas
- 📱 **Design Responsivo**: Interface adaptável para desktop e mobile
- 🎨 **Interface Moderna**: Design limpo e intuitivo com animações suaves
- 🖼️ **Suporte a Imagens**: Adicionar imagens às tarefas via URL
- 📅 **Data de Vencimento**: Definir prazos para as tarefas
- 🏷️ **Categorização**: Organizar tarefas por categorias (Trabalho, Pessoal, Estudos, Saúde, Outros)
- ⚡ **Prioridades**: Definir níveis de prioridade (Alta, Média, Baixa)

## Estrutura do Projeto

```
src/
├── components/          # Componentes reutilizáveis
│   ├── Header.js       # Cabeçalho da aplicação
│   ├── TarefaCard.js   # Card individual de tarefa
│   └── FormularioTarefa.js # Formulário para criar/editar tarefas
├── pages/              # Páginas da aplicação
│   ├── ListaTarefas.js # Página principal com lista de tarefas
│   ├── CadastroTarefa.js # Página de cadastro de nova tarefa
│   ├── EditarTarefa.js # Página de edição de tarefa
│   └── DetalhesTarefa.js # Página de detalhes da tarefa
├── services/           # Serviços de API
│   └── api.js         # Configuração do Axios e endpoints
└── styles/            # Arquivos CSS
```

## Instalação e Execução

### Pré-requisitos
- Node.js (versão 14 ou superior)
- npm ou yarn

### Passos para instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd frontend
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
Crie um arquivo `.env` na raiz do projeto:
```
REACT_APP_API_URL=http://localhost:5000/api
```

4. Execute a aplicação:

Para desenvolvimento:
```bash
npm start
```

Para build de produção:
```bash
npm run build
```

A aplicação estará disponível em `http://localhost:3000`

## Navegação

A aplicação possui as seguintes rotas:

- `/` - Página inicial com lista de tarefas
- `/cadastrar` - Formulário para criar nova tarefa
- `/editar/:id` - Formulário para editar tarefa existente
- `/detalhes/:id` - Página com detalhes completos da tarefa

## Componentes Principais

### Header
- Navegação principal da aplicação
- Links para páginas principais
- Design responsivo com gradiente

### TarefaCard
- Exibe informações resumidas da tarefa
- Ações rápidas (concluir, editar, excluir, visualizar)
- Indicadores visuais de categoria e prioridade
- Suporte a imagens

### FormularioTarefa
- Formulário reutilizável para criar e editar tarefas
- Validação de campos obrigatórios
- Campos: título, descrição, categoria, prioridade, imagem, data de vencimento

### ListaTarefas
- Exibe todas as tarefas em formato de grid
- Filtros por status e categoria
- Estatísticas em tempo real
- Estado vazio quando não há tarefas

## Recursos de Design

- **Paleta de Cores**: Tons de azul, verde e cinza para uma interface profissional
- **Tipografia**: Fonte system padrão para melhor legibilidade
- **Ícones**: Emojis para representar categorias e ações
- **Animações**: Transições suaves em hover e interações
- **Responsividade**: Grid adaptável e layout flexível

## Integração com Backend

A aplicação se conecta com a API backend através do serviço `api.js` que utiliza Axios para:

- Listar todas as tarefas
- Buscar tarefa por ID
- Criar nova tarefa
- Atualizar tarefa existente
- Excluir tarefa

## Scripts Disponíveis

- `npm start` - Inicia o servidor de desenvolvimento
- `npm run build` - Cria build otimizado para produção
- `npm test` - Executa os testes
- `npm run eject` - Remove a abstração do Create React App (irreversível)

## Conceitos React Aplicados

- ✅ **Componentes Funcionais**: Todos os componentes utilizam function components
- ✅ **Hooks**: useState, useEffect, useParams, useNavigate
- ✅ **Props**: Passagem de dados entre componentes
- ✅ **Props Desestruturados**: Extração de propriedades nos parâmetros
- ✅ **Lift State Up**: Estado compartilhado entre componentes
- ✅ **Renderização Condicional**: Exibição baseada em condições
- ✅ **Eventos**: onClick, onChange, onSubmit
- ✅ **React Router**: Navegação entre páginas
- ✅ **Axios**: Requisições HTTP para API

## Melhorias Futuras

- [ ] Implementar busca por texto
- [ ] Adicionar drag & drop para reordenar tarefas
- [ ] Implementar notificações push
- [ ] Adicionar modo escuro
- [ ] Implementar upload de imagens local
- [ ] Adicionar tags personalizadas
- [ ] Implementar filtros avançados

