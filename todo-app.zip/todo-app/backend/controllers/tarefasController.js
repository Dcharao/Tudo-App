const Tarefa = require('../models/Tarefa');

// GET /api/tarefas - Listar todas as tarefas
const listarTarefas = async (req, res) => {
  try {
    const tarefas = await Tarefa.find().sort({ dataCriacao: -1 });
    res.json(tarefas);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar tarefas', error: error.message });
  }
};

// GET /api/tarefas/:id - Buscar tarefa por ID
const buscarTarefaPorId = async (req, res) => {
  try {
    const tarefa = await Tarefa.findById(req.params.id);
    if (!tarefa) {
      return res.status(404).json({ message: 'Tarefa não encontrada' });
    }
    res.json(tarefa);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar tarefa', error: error.message });
  }
};

// POST /api/tarefas - Criar nova tarefa
const criarTarefa = async (req, res) => {
  try {
    const { titulo, descricao, categoria, prioridade, imagem, dataVencimento } = req.body;
    
    const novaTarefa = new Tarefa({
      titulo,
      descricao,
      categoria,
      prioridade,
      imagem,
      dataVencimento
    });

    const tarefaSalva = await novaTarefa.save();
    res.status(201).json(tarefaSalva);
  } catch (error) {
    res.status(400).json({ message: 'Erro ao criar tarefa', error: error.message });
  }
};

// PUT /api/tarefas/:id - Atualizar tarefa
const atualizarTarefa = async (req, res) => {
  try {
    const { titulo, descricao, categoria, prioridade, concluida, imagem, dataVencimento } = req.body;
    
    const tarefaAtualizada = await Tarefa.findByIdAndUpdate(
      req.params.id,
      {
        titulo,
        descricao,
        categoria,
        prioridade,
        concluida,
        imagem,
        dataVencimento
      },
      { new: true, runValidators: true }
    );

    if (!tarefaAtualizada) {
      return res.status(404).json({ message: 'Tarefa não encontrada' });
    }

    res.json(tarefaAtualizada);
  } catch (error) {
    res.status(400).json({ message: 'Erro ao atualizar tarefa', error: error.message });
  }
};

// DELETE /api/tarefas/:id - Excluir tarefa
const excluirTarefa = async (req, res) => {
  try {
    const tarefaExcluida = await Tarefa.findByIdAndDelete(req.params.id);
    
    if (!tarefaExcluida) {
      return res.status(404).json({ message: 'Tarefa não encontrada' });
    }

    res.json({ message: 'Tarefa excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir tarefa', error: error.message });
  }
};

module.exports = {
  listarTarefas,
  buscarTarefaPorId,
  criarTarefa,
  atualizarTarefa,
  excluirTarefa
};

