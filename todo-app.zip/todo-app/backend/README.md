# Backend - Lista de Tarefas

API REST para aplicação de lista de tarefas desenvolvida com Node.js, Express e MongoDB.

## Tecnologias Utilizadas

- Node.js
- Express.js
- MongoDB
- Mongoose
- CORS
- dotenv

## Instalação e Execução

### Pré-requisitos
- Node.js (versão 14 ou superior)
- MongoDB (local ou MongoDB Atlas)

### Passos para instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd backend
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
Crie um arquivo `.env` na raiz do projeto com:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/todoapp
```

4. Execute a aplicação:

Para desenvolvimento:
```bash
npm run dev
```

Para produção:
```bash
npm start
```

A API estará disponível em `http://localhost:5000`

## Rotas da API

### Tarefas

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/tarefas` | Lista todas as tarefas |
| GET | `/api/tarefas/:id` | Busca uma tarefa por ID |
| POST | `/api/tarefas` | Cria uma nova tarefa |
| PUT | `/api/tarefas/:id` | Atualiza uma tarefa |
| DELETE | `/api/tarefas/:id` | Exclui uma tarefa |

### Exemplos de JSON

#### Criar Tarefa (POST /api/tarefas)
```json
{
  "titulo": "Estudar React",
  "descricao": "Revisar conceitos de hooks e componentes",
  "categoria": "Estudos",
  "prioridade": "Alta",
  "imagem": "https://exemplo.com/imagem.jpg",
  "dataVencimento": "2025-06-30T23:59:59.000Z"
}
```

#### Atualizar Tarefa (PUT /api/tarefas/:id)
```json
{
  "titulo": "Estudar React - Atualizado",
  "descricao": "Revisar conceitos de hooks, componentes e context",
  "categoria": "Estudos",
  "prioridade": "Alta",
  "concluida": true,
  "imagem": "https://exemplo.com/imagem.jpg",
  "dataVencimento": "2025-06-30T23:59:59.000Z"
}
```

## Estrutura do Projeto

```
backend/
├── controllers/
│   └── tarefasController.js
├── models/
│   └── Tarefa.js
├── routes/
│   └── tarefas.js
├── .env
├── server.js
└── package.json
```

## Schema da Tarefa

```javascript
{
  titulo: String (obrigatório),
  descricao: String (obrigatório),
  categoria: String (enum: ['Trabalho', 'Pessoal', 'Estudos', 'Saúde', 'Outros']),
  prioridade: String (enum: ['Baixa', 'Média', 'Alta']),
  concluida: Boolean (default: false),
  imagem: String (URL da imagem),
  dataCriacao: Date (default: Date.now),
  dataVencimento: Date (opcional)
}
```

