const express = require('express');
const router = express.Router();
const {
  listarTarefas,
  buscarTarefaPorId,
  criarTarefa,
  atualizarTarefa,
  excluirTarefa
} = require('../controllers/tarefasController');

// GET /api/tarefas - Listar todas as tarefas
router.get('/', listarTarefas);

// GET /api/tarefas/:id - Buscar tarefa por ID
router.get('/:id', buscarTarefaPorId);

// POST /api/tarefas - Criar nova tarefa
router.post('/', criarTarefa);

// PUT /api/tarefas/:id - Atualizar tarefa
router.put('/:id', atualizarTarefa);

// DELETE /api/tarefas/:id - Excluir tarefa
router.delete('/:id', excluirTarefa);

module.exports = router;

