const mongoose = require('mongoose');

const tarefaSchema = new mongoose.Schema({
  titulo: {
    type: String,
    required: true,
    trim: true
  },
  descricao: {
    type: String,
    required: true,
    trim: true
  },
  categoria: {
    type: String,
    required: true,
    enum: ['Trabalho', 'Pessoal', 'Estudos', 'Saúde', 'Outros'],
    default: 'Outros'
  },
  prioridade: {
    type: String,
    required: true,
    enum: ['Baixa', 'Média', 'Alta'],
    default: 'Média'
  },
  concluida: {
    type: Boolean,
    default: false
  },
  imagem: {
    type: String,
    default: ''
  },
  dataCriacao: {
    type: Date,
    default: Date.now
  },
  dataVencimento: {
    type: Date,
    required: false
  }
});

module.exports = mongoose.model('Tarefa', tarefaSchema);

